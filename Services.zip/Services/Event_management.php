<?php include '../dashboard/main/ajax/datab.php'; ?> 

<!DOCTYPE html>
<html class="no-js" lang="en">
    
<!-- Mirrored from www.annimexweb.com/items/hema/index5-tools-parts.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 04 Oct 2023 07:12:57 GMT -->
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="description" content="description">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--BootStrap icons-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <!-- Title Of Site -->
        <title>Samuthrika Academy</title>
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo $path; ?>assets/images/favicon.png" />
        <!-- Plugins CSS -->
        <link rel="stylesheet" href="<?php echo $path; ?>assets/css/plugins.css">
        <!-- Main Style CSS -->
        <link rel="stylesheet" href="<?php echo $path; ?>assets/css/style-min.css">
        <link rel="stylesheet" href="<?php echo $path; ?>assets/css/responsive.css">
    </head>

    <style>
  
    .footer-img{
        margin-bottom: 14px;
    }

    .btn-hover{
        
    }

    </style>

    <body class="template-index index-demo5">
        <!--Page Wrapper-->
        <div class="page-wrapper">   
            <!--Header-->
            <?php include '../header.php';?>
            <!--End Header-->
           
            <!--Mobile Menu-->
            <?php include '../sidebar.php';?>
            <!--End Mobile Menu-->

            <!-- Body Container -->
            <div id="page-content">               
                <!--Home Slideshow-->
                <!-- <section class="slideshow slideshow-wrapper">
                    <div class="home-slideshow slick-arrow-dots">
                        <div class="slide">
                            <div class="slideshow-wrap">
                                <picture>
                                    <source media="(max-width:318px)" srcset="<?php echo $path; ?>assets/images/slideshow/demo1-banner2-mbl.jpg" width="1150" height="800">
                                    <img class="blur-up lazyload" src="<?php echo $path; ?>assets/images/slideshow/demo1-banner2.jpg" alt="slideshow" title="" width="1920" height="795" />
                                </picture> 
                                <div class="container">
                                    <div class="slideshow-content slideshow-overlay middle-right">
                                        <div class="slideshow-content-in">
                                            <div class="wrap-caption animation style1">
                                                <p class="ss-sub-title xs-hide">Best Coaching here... </p>
                                                <h2 class="ss-mega-title">Samuthrika <br>Academy</h2>  
                                                <p class="ss-sub-title xs-hide">Our Courses are listed below</p>
                                                <div class="ss-btnWrap">
                                                    <a class="btn btn-primary" href="#course-category" style="transition:1s all ease;" id="btn-hover">View now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        <div class="slide">
                            <div class="slideshow-wrap">
                                <picture>
                                    <source media="(max-width:318px)" srcset="<?php echo $path; ?>assets/images/slideshow/demo1-banner3-mbl.jpg" width="1150" height="800">
                                    <img class="blur-up lazyload" src="<?php echo $path; ?>assets/images/slideshow/demo1-banner2.jpg" alt="slideshow" title="" width="1920" height="795" />
                                </picture>  
                                <div class="container">
                                    <div class="slideshow-content slideshow-overlay middle-right">
                                        <div class="slideshow-content-in">
                                            <div class="wrap-caption animation style1">
                                                <h2 class="ss-mega-title">Our Next <br>Jewellary Products</h2>
                                                <p class="ss-sub-title xs-hide">The outfit that blend elegance and style for your casual wear</p>
                                                <p class="ss-sub-title xs-hide">The classic elegant jewellarys</p>
                                                <div class="ss-btnWrap">
                                                    <a class="btn btn-primary" href="jewel-product.php">Shop now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="slide">
                            <div class="slideshow-wrap">
                                <picture>
                                    <source media="(max-width:318px)" srcset="<?php echo $path; ?>assets/images/slideshow/demo1-banner3-mbl.jpg" width="1150" height="800">
                                    <img class="blur-up lazyload" src="<?php echo $path; ?>assets/images/slideshow/demo1-banner2.jpg" alt="slideshow" title="" width="1920" height="795" />
                                </picture>  
                                <div class="container">
                                    <div class="slideshow-content slideshow-overlay middle-right">
                                        <div class="slideshow-content-in">
                                            <div class="wrap-caption animation style1">
                                                <h2 class="ss-mega-title">Our <br>Tailoring Products</h2>
                                                <p class="ss-sub-title xs-hide">The outfit that blend elegance and style for your casual wear</p>
                                                <p class="ss-sub-title xs-hide">The classic elegant jewellarys</p>
                                                <div class="ss-btnWrap">
                                                    <a class="btn btn-primary" href="tailoring-product.php">Shop now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="slide">
                            <div class="slideshow-wrap">
                                <picture>
                                    <source media="(max-width:318px)" srcset="<?php echo $path; ?>assets/images/slideshow/demo1-banner3-mbl.jpg" width="1150" height="800">
                                    <img class="blur-up lazyload" src="<?php echo $path; ?>assets/images/slideshow/demo1-banner2.jpg" alt="slideshow" title="" width="1920" height="795" />
                                </picture>  
                                <div class="container">
                                    <div class="slideshow-content slideshow-overlay middle-right">
                                        <div class="slideshow-content-in">
                                            <div class="wrap-caption animation style1">
                                                <h2 class="ss-mega-title">Our Next <br>Clothing Products</h2>
                                                <p class="ss-sub-title xs-hide">The outfit that blend elegance and style for your casual wear</p>
                                                <p class="ss-sub-title xs-hide">The classic elegant jewellarys</p>
                                                <div class="ss-btnWrap">
                                                    <a class="btn btn-primary" href="cloth-product.php">Shop now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> -->
                <!--End Home Slideshow-->

                <!--Popular Categories-->
                 <!-- <section class="section collection-slider section-clr cs_1"> 
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-12 col-sm-12 col-md-12">
                                <div class="section-header">
                                    <h2> Categories</h2>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12">
                                <div class="collection-slider-4items gp15 arwOut5 hov-arrow dots-hide">
                                    <div class="category-item zoomscal-hov">
                                        <a href="#" class="category-link clr-none">
                                            <div class="zoom-scal zoom-scal-nopb"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/dance.jpg" src="<?php echo $path; ?>assets/images/dance.jpg" alt="collection" title="" width="300" height="300" /></div>
                                            <div class="details mt-3 text-center">
                                                <h4 class="category-title mb-0">Dance</h4>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="category-item zoomscal-hov">
                                        <a href="#" class="category-link clr-none">
                                            <div class="zoom-scal zoom-scal-nopb"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/fitness.jpg" src="<?php echo $path; ?>assets/images/fitness.jpg" alt="collection" title="" width="300" height="300" /></div>
                                            <div class="details mt-3 text-center">
                                                <h4 class="category-title mb-0">Fitness</h4>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="category-item zoomscal-hov">
                                        <a href="#" class="category-link clr-none">
                                            <div class="zoom-scal zoom-scal-nopb"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/School Classes Assisted.jpg" src="<?php echo $path; ?>assets/images/School Tuition.jpg alt="collection" title="" width="300" height="300" /></div>
                                            <div class="details mt-3 text-center">
                                                <h4 class="category-title mb-0">School Tuition</h4>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="category-item zoomscal-hov">
                                        <a href="#" class="category-link clr-none">
                                            <div class="zoom-scal zoom-scal-nopb"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/instruments.jpg" src="<?php echo $path; ?>assets/images/instruments.jpg" alt="collection" title="" width="300" height="300" /></div>
                                            <div class="details mt-3 text-center">
                                                <h4 class="category-title mb-0">Music Instruments</h4>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="category-item zoomscal-hov">
                                        <a href="#" class="category-link clr-none">
                                            <div class="zoom-scal zoom-scal-nopb"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/handwrite.jpg" src="<?php echo $path; ?>assets/handwrite.jpg" alt="collection" title="" width="300" height="300" /></div>
                                            <div class="details mt-3 text-center">
                                                <h4 class="category-title mb-0">Traditional Courses</h4>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> -->
                <!--End Popular Categories-->

                <!--Products With Tabs-->
                <section class="section product-slider tab-slider-product pb-0" id="course-category">
                    <div class="container">
                        <div class="section-header d-none">
                            <h2>Special Offers</h2>
                            <p>Browse the huge variety of our best seller</p>
                        </div>

          


                            <div class="tab-content" id="productTabsContent">
                            
                            
                                <div class="tab-pane show active" id="bestsellers" role="tabpanel" aria-labelledby="bestsellers-tab">
                               
                                <!--Product Grid-->
                                    <div class="grid-products grid-view-items">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12 product-layout-info">
                            <!-- Product Details -->
                            <div class="product-single-meta">

                                <div class="section-header">
                                    <h1 style="font-size:2.3rem" class="pt-4">Book for <span
                                            style="color:orange;">Event management</span></h1>
                                </div>

                                <!-- Product Info -->
                                <table id="product-table" class="table  table-secondary bg-secondary text-dark  table-hover">
                                    <thead class="table-dark">
                                       
                                            <th>S.no</th>
                                            <th>Course Title</th>
                                            <th>Select</th>
                                      
                                    </thead>    
                                    <tbody>
                                        <tr>
                                         <td>1</td>
                                            <td>Birthday Parties</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Birthday Parties" />

                                                </div>
                                            </td>

                                        </tr>

                                        <tr>
                                            <td>2</td>
                                        <td>Marriage Parties</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Marriage Parties" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>3</td>
                                            <td>Corprate events</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Corprate events" />

                                                </div>
                                            </td>
                                        </tr>


                                        <tr>
                                            <td>4</td>
                                        <td>RoadSide Events</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="RoadSide Events" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>5</td>
                                        <td>Flash mobs</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Flash mobs" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>6</td>
                                        <td>Bharathnatyam Troops </td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Bharathnatyam Troops" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>7</td>
                                        <td>Folk-Dance Troop </td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Folk-Dance Troop " />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>8</td>
                                        <td>Dance Troop </td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Dance Troop" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>9</td>
                                        <td>Master of ceremony</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Master of ceremony" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>10</td>
                                        <td>Booking Rj's / Vj's</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Booking Rj's / Vj's" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>11</td>
                                        <td>Booking Cinema star's for events</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Booking Cinema star's for events" />

                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>12</td>
                                        <td>Others</td>
                                            <td>
                                                <div class="form-check lang">


                                                    <input id="c1" name="course" type="checkbox"
                                                        value="Others" />

                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <!-- End Product Info -->


                            </div>
                            <!-- End Product Details -->


                            <!-- Product Form -->
                            <!-- <form method="post" action="#" class="product-form product-form-border hidedropdown"> -->
                            <!-- Product Action -->
                            <div class="product-action w-100 d-flex-wrap mb-2">


                                <!-- Product Add -->
                                <div class="product-form-submit addcart fl-1 ms-0 mt-0">
                                    <button name="add"
                                        class="btn btn-secondary product-form-cart-submit" id="enquiry-form"><span>Add to cart</span></button>
                                </div>
                                <!-- Product Add -->

                            </div>
                            <!-- End Product Action -->

                            <!-- </form> -->
                            <!-- End Product Form -->

                            <!-- Social Sharing -->
                            <div class="social-sharing d-flex-center mt-2 lh-lg">
                                <span class="sharing-lbl fw-600">Share :</span>

                                <!-- Copy to Clipboard Button -->
                                <button class="d-flex-center btn btn-link btn--share copy-to-clipboard"
                                    onclick="copyToClipboard()">
                                    <i class="icon anm anm-share"></i>
                                </button>
                            </div>
                            <!-- End Social Sharing -->
                            <br><br>
                        </div> 

                                        <!--<div class="view-collection text-center mt-4 mt-md-5">
                                            <a href="shop-left-sidebar.html" class="btn btn-primary btn-lg">View Collection</a>
                                        </div>-->

                                    </div>
                                <!--End Product Grid-->
                                </div>

                                <div class="tab-pane" id="newarrivals" role="tabpanel" aria-labelledby="newarrivals-tab">
                                    <!--Product Grid-->
                                    <div class="grid-products grid-view-items">
                                        <div class="row col-row product-options row-cols-xl-4 row-cols-lg-4 row-cols-md-3 row-cols-sm-3 row-cols-2">                                   
                                           
                                        <p>no contents in tailoring-product</p>

                                        </div>  

                                        <!--<div class="view-collection text-center mt-4 mt-md-5">
                                            <a href="shop-left-sidebar.html" class="btn btn-primary btn-lg">View Collection</a>
                                        </div>-->

                                    </div>
                                    <!--End Product Grid-->
                                </div>



                                <div class="tab-pane" id="toprated" role="tabpanel" aria-labelledby="toprated-tab">
                                    <!--Product Grid-->
                                    <div class="grid-products grid-view-items">
                                        <div class="row col-row product-options row-cols-xl-4 row-cols-lg-4 row-cols-md-3 row-cols-sm-3 row-cols-2">                                                                            
                                          
                                        <p>no contents in annual coreo</p>
                                     

                                        </div>

                                        <!--<div class="view-collection text-center mt-4 mt-md-5">
                                            <a href="shop-left-sidebar.html" class="btn btn-secondary btn-lg">View Collection</a>
                                        </div>-->

                                    </div>
                                    <!--End Product Grid-->
                                </div>



                                <div class="tab-pane" id="toppreparated" role="tabpanel" aria-labelledby="toppreparated-tab">
                                    <!--Product Grid-->
                                    <div class="grid-products grid-view-items">
                                        <div class="row col-row product-options row-cols-xl-4 row-cols-lg-4 row-cols-md-3 row-cols-sm-3 row-cols-2">                                                                            
                                          
                                        <p>no contents in school coreo</p>
                                     

                                        </div>

                                        <!--<div class="view-collection text-center mt-4 mt-md-5">
                                            <a href="shop-left-sidebar.html" class="btn btn-secondary btn-lg">View Collection</a>
                                        </div>-->

                                    </div>
                                    <!--End Product Grid-->
                                </div>



                            </div>
                        </div>
                    </div>
                </section>
                <!--End Products With Tabs-->

                <!--Promo bar
                <section class="section pb-0">
                    <div class="container">
                        <div class="section-header d-none">
                            <h2>Promotion</h2>
                        </div>

                        <div class="top-info-bar style1 promoMsg">
                            <div class="topBar-slider-style1">
                                <div class="item text-center d-flex d-flex-justify-center">
                                    Best Deals and Lowest Price on Top Brands&nbsp;:&nbsp;<b>Get 25% Flat Off on Tools</b>
                                </div>
                                <div class="item text-center d-flex d-flex-justify-center">
                                    Leading&nbsp;<b>Hand Tools</b> &nbsp;Manufacturer. All Kinds Of&nbsp;<b>Safety Tools</b>&nbsp;Available.
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                End Promo bar-->

                <!--Collection 
                <section class="section collection-banners three-one-bnr">
                    <div class="container">                      
                        <div class="collection-banner-grid three-bnr">
                            <div class="row sp-row">
                                <div class="col-12 col-sm-12 col-md-5 col-lg-5 collection-banner-item">
                                    <div class="collection-item sp-col">
                                        <a href="shop-left-sidebar.html" class="zoom-scal clr-none">
                                            <div class="img">
                                                <img class="w-100 blur-up lazyload" data-src="<?php echo $path; ?>assets/images/collection/demo5-ct-img1.jpg" src="<?php echo $path; ?>assets/images/collection/demo5-ct-img1.jpg" alt="collection" title="" width="533" height="447" />
                                            </div>
                                            <div class="details middle-left">
                                                <div class="inner text-left">
                                                    <h3 class="title">Other<br>Classes</h3>
                                                    <p class="counts">25 Products</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>                                
                                </div>
                                <div class="col-12 col-sm-12 col-md-2 col-lg-2 collection-banner-item">
                                    <div class="collection-item sp-col h-100">
                                        <a href="shop-left-sidebar.html" class="zoom-scal clr-none h-100">
                                            <div class="img h-100">
                                                <img class="w-100 h-100 blur-up lazyload" data-src="<?php echo $path; ?>assets/images/collection/demo5-ct-img2.jpg" src="<?php echo $path; ?>assets/images/collection/demo5-ct-img2.jpg" alt="collection" title="" width="533" height="447" />
                                            </div>
                                            <div class="details middle-center text-center d-flex-justify-center whiteText offerText w-100 h-100 p-0">
                                                <p class="tex-top text-uppercase m-0">Super Sale</p>
                                                <h3 class="pro-sale m-0"><span class="tex1 d-block">Get 40%</span><span class="tex2 d-block my-2 my-md-0">OFF</span><span class="tex3 d-block">All Products</span></h3>
                                                <p class="tex-bom m-0">Discount Code <span class="code fw-bold m-0 d-block text-uppercase">Hema40</span></p>
                                            </div>
                                        </a>
                                    </div>                                
                                </div>
                                <div class="col-12 col-sm-12 col-md-5 col-lg-5 collection-banner-item">
                                    <div class="collection-item sp-col">
                                        <a href="shop-left-sidebar.html" class="zoom-scal clr-none">
                                            <div class="img">
                                                <img class="w-100 blur-up lazyload" data-src="<?php echo $path; ?>assets/images/collection/demo5-ct-img3.jpg" src="<?php echo $path; ?>assets/images/collection/demo5-ct-img3.jpg" alt="collection" title="" width="533" height="447" />
                                            </div>
                                            <div class="details middle-right">
                                                <div class="inner text-left">
                                                    <h3 class="title">Garden <br>Tools</h3>
                                                    <p class="counts">12 Products</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                End Collection banner-->

               

                <!--Blog Post-->
                <!-- <section class="section home-blog-post">
                    <div class="container">
                        <div class="section-header">
                            <h2>Latest from our Blog</h2>
                        </div>

                        <div class="blog-slider-3items blog-post-style2 gp15 arwOut5 hov-arrow">
                            <div class="blog-item">
                                <div class="blog-article zoomscal-hov bg-white">
                                    <div class="blog-img">
                                        <a class="featured-image zoom-scal m-0" href="blog-details.html"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/blog/demo5-post1.jpg" src="<?php echo $path; ?>assets/images/blog/demo5-post1.jpg" alt="New shop collection our shop" width="740" height="410" /></a>
                                    </div>
                                    <div class="blog-content py-4 pb-0">
                                        <ul class="publish-detail d-flex-wrap text-uppercase mb-2">                      
                                            <li><i class="icon anm anm-user-al"></i> <span>Online / Offline</span></li>
                                            <li><i class="icon anm anm-calendar"></i> <time datetime="">Mon - Fri ( 1hrs or 2hrs )</time></li>
                                        </ul>
                                        <h2 class="h3 m-0 text-none"><a href="blog-details.html">New shop collection our shop</a></h2>                                                                                
                                        <div class="blog-bottom d-flex-center justify-content-between mt-3">
                                            <a href="blog-details.html" class="text-link text-decoration-none text-uppercase">Read More<i class="icon anm anm-arw-right ms-2"></i></a>
                                            <a href="#" class="text-link text-decoration-none"><i class="icon anm anm-comments-l me-2"></i>12</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="blog-item">
                                <div class="blog-article zoomscal-hov bg-white">
                                    <div class="blog-img">
                                        <a class="featured-image zoom-scal m-0" href="blog-details.html"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/blog/demo5-post2.jpg" src="<?php echo $path; ?>assets/images/blog/demo5-post2.jpg" alt="Gift ideas for everyone" width="740" height="410" /></a>
                                    </div>
                                    <div class="blog-content py-4 pb-0">
                                        <ul class="publish-detail d-flex-wrap text-uppercase mb-2">                      
                                            <li><i class="icon anm anm-user-al"></i> <span>Online / Offline</span></li>
                                            <li><i class="icon anm anm-calendar"></i> <time datetime="">Jan 24, 2023</time></li>
                                        </ul>
                                        <h2 class="h3 m-0 text-none"><a href="blog-details.html">Best gift ideas for everyone</a></h2>                                                                             
                                        <div class="blog-bottom d-flex-center justify-content-between mt-3">
                                            <a href="blog-details.html" class="text-link text-decoration-none text-uppercase">Read More<i class="icon anm anm-arw-right ms-2"></i></a>
                                            <a href="#" class="text-link text-decoration-none"><i class="icon anm anm-comments-l me-2"></i>12</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="blog-item">
                                <div class="blog-article zoomscal-hov bg-white">
                                    <div class="blog-img">
                                        <a class="featured-image zoom-scal m-0" href="blog-details.html"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/blog/demo5-post3.jpg" src="<?php echo $path; ?>assets/images/blog/demo5-post3.jpg" alt="Sales with best collection" width="740" height="410" /></a>
                                    </div>
                                    <div class="blog-content py-4 pb-0">
                                        <ul class="publish-detail d-flex-wrap text-uppercase mb-2">                      
                                            <li><i class="icon anm anm-user-al"></i> <span>Online / Offline</span></li>
                                            <li><i class="icon anm anm-calendar"></i> <time datetime="">Feb 14, 2023</time></li>
                                        </ul>
                                        <h2 class="h3 m-0 text-none"><a href="blog-details.html">Sales with best collection</a></h2>                                     
                                        <div class="blog-bottom d-flex-center justify-content-between mt-3">
                                            <a href="blog-details.html" class="text-link text-decoration-none text-uppercase">Read More<i class="icon anm anm-arw-right ms-2"></i></a>
                                            <a href="#" class="text-link text-decoration-none"><i class="icon anm anm-comments-l me-2"></i>12</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> -->
                <!--End Blog Post-->

                <!--Service Section
                <section class="section service-section section-clr mt-m6">
                    <div class="container">
                        <div class="service-info text-center service-slider-5items gp15 arwOut5 slick-arrow-dots">
                            <div class="service-wrap">
                                <div class="service-icon mb-2 pb-1">
                                    <i class="icon anm anm-check-badge-r"></i>
                                </div>
                                <div class="service-content">
                                    <h3 class="fs-5 mb-2">Products Quality</h3>
                                    <span class="text-muted">Comprehensive quality control and affordable prices</span>
                                </div>
                            </div>
                            <div class="service-wrap">
                                <div class="service-icon mb-2 pb-1">
                                    <i class="icon anm anm-home-r"></i>
                                </div>
                                <div class="service-content">
                                    <h3 class="fs-5 mb-2">Global Warehouse</h3>
                                    <span class="text-muted">Shop from 20+ warehouses world wide.</span>
                                </div>
                            </div>
                            <div class="service-wrap">
                                <div class="service-icon mb-2 pb-1">
                                    <i class="icon anm anm-truck-r"></i>
                                </div>
                                <div class="service-content">
                                    <h3 class="fs-5 mb-2">Fast Shipping</h3>
                                    <span class="text-muted">Fast and convenient door to door delivery</span>
                                </div>
                            </div>
                            <div class="service-wrap">
                                <div class="service-icon mb-2 pb-1">
                                    <i class="icon anm anm-lock-ar"></i>
                                </div>
                                <div class="service-content">
                                    <h3 class="fs-5 mb-2">Payment Security</h3>
                                    <span class="text-muted">More than 8 different secure payment methods</span>
                                </div>
                            </div>
                            <div class="service-wrap">
                                <div class="service-icon mb-2 pb-1">
                                    <i class="icon anm anm-phone-call-l"></i>
                                </div>
                                <div class="service-content">
                                    <h3 class="fs-5 mb-2">Dedicated Support</h3>
                                    <span class="text-muted">24/7 Customer Service - We're here & happy to help!</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                End Service Section-->

            </div>
            <!-- End Body Container -->

            <!--Footer-->
            <div class="footer footer-5 ftr-bg-black">


                <div class="footer-top border-0 clearfix">
                    <div class="container">                       
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 mb-4 mb-lg-0">
                                <div class="footer-newsletter icon-arrow">
                                <img src="<?php echo $path; ?>assets/images/samlogo.jpg" alt="Hema Multipurpose Html Template" title="Hema Multipurpose Html Template" class="footer-img" width="250" height="70" /><br>
                                        <p>Samuthrika academy, is our educational institution, we offers specialized tutoring, instruction, or training to students or individuals seeking to improve their skills, knowledge, or performance in a particular subject, field, or area. </p>
                                   
                                       
                                        <ul class="list-inline social-icons d-inline-flex mt-3 pt-3" >
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Facebook"><i class="icon anm anm-facebook-f"></i></a></li>
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Twitter"><i class="icon anm anm-twitter"></i></a></li>
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Pinterest"><i class="icon anm anm-pinterest-p"></i></a></li>
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Linkedin"><i class="icon anm anm-linkedin-in"></i></a></li>
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Instagram"><i class="icon anm anm-instagram"></i></a></li>
                                        <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Youtube"><i class="icon anm anm-youtube"></i></a></li>
                                  
                                        
                                    </ul>
                                    
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-4 col-lg-3 footer-links ps-lg-5">
                                <h4 class="h4">My Account</h4>
                                <ul>
                                    <li><a href="my-account.html">My Account</a></li>
                                    <li><a href="faqs-style1.html">Order History</a></li>
                                    <li><a href="contact-us.php">Contact Us</a></li>
                                    <li><a href="#">Orders & Cart</a></li>
                                    <li><a href="#">Support Center</a></li>
                                </ul>
                            </div>
                            <div class="col-12 col-sm-12 col-md-4 col-lg-2 footer-links">
                                <h4 class="h4">Information</h4>
                                <ul>
                                    <li><a href="aboutus-style1.html">About Us</a></li>
                                    <li><a href="contact-us.php">Contact Us</a></li>
                                    <li><a href="blog-grid.html">Latest News</a></li>                                   
                                    <li><a href="#">Privacy policy</a></li>
                                    <li><a href="#">Terms &amp; condition</a></li>
                                </ul>
                            </div>                              
                            <div class="col-12 col-sm-12 col-md-4 col-lg-3 footer-contact">
                                <h4 class="h4">Contact Info</h4>
                                <p class="address d-flex"><i class="icon anm anm-map-marker-al pt-1"></i> 10th Cross West Extension, Thillai Nagar, Trichy - 620018</p>
                                <p class="phone d-flex align-items-center"><i class="icon anm anm-phone-l"></i>  <b class="me-2 fw-400">Mobile.No</b> <a href="tel:401234567890">07947336473</a></p>
                                <p class="email d-flex align-items-center"><i class="icon anm anm-envelope-l"></i> <b class="me-1 d-none">Email:</b> <a href="mailto:info@example.com">info@example.com</a></p>
                                <p class="work-hour d-flex mb-0"><i class="icon anm anm-clock-r pt-1"></i><span class="hour-time">Working Hours: <br/>Mon - Sun / 9:00 AM - 8:00 PM</span></p>    
                          
                            </div>
                        </div>
                          
                    </div>                      
                    <p class="copytext" style="text-align:center;margin-top:2%;">&copy; Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, exercitationem? Nostrum labore praesentium eaque suscipit ipsa et mollitia officia adipisci consequuntur ratione veniam dolore enim maiores magnam, pariatur aspernatur consectetur..</p>
                       

                </div>        

                <!--<div class="footer-bottom clearfix">
                    <div class="container">
                        <div class="d-flex-center flex-column justify-content-md-between flex-md-row-reverse py-lg-1">
                           
                       
                        </div>
                    </div>
                </div>-->

            </div>
            <!--End Footer-->

            <!--Scoll Top-->
            <div id="site-scroll" style="background-color: orangered;"><i class="icon anm anm-arw-up"></i></div>
            <!--End Scoll Top-->

            

            <!-- Product Quickshop Modal-->
            <div class="quickview-modal modal fade show" id="quickview_form" tabindex="-1" style="display: none;" aria-hidden="true">           
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" fdprocessedid="8upl9f"></button>
                            <div class="row">
                                  
                                <div class="formFeilds contact-form form-vertical mb-4 mb-lg-0">
                                    <div class="section-header">
                                        <h2>Booking form</h2>
                                    </div>

                                    <div name="contactus"  id="contact-form" class="contact-form">	
                                        <div class="form-row">
                                            <div class="col-12 col-sm-12 col-md-6 col-lg-4">
                                                <div class="form-group">
                                                    <input type="text" id="ContactFormName" name="name" class="form-control" placeholder="Name">
                                                    <span class="error_msg" id="name_error"></span>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-6 col-lg-4">                               
                                                <div class="form-group">
                                                    <input type="email" id="ContactFormEmail" name="email" class="form-control" placeholder="Email">
                                                    <span class="error_msg" id="email_error"></span>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-6 col-lg-4">                               
                                                <div class="form-group">
                                                    <input type="tel" id="ContactFormPhone" name="phone" class="form-control" placeholder="Phone">
                                                    <span class="error_msg" id="email_error"></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-row">
                                            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                                <div class="form-group">
                                                    <textarea id="ContactFormAddress" name="message" class="form-control" rows="6" placeholder="Address" style="height: 115px;"></textarea>
                                                    <span class="error_msg" id="message_error"></span>
                                                </div>
                                            </div>  
                                        </div>
                                        <div class="form-row">
                                            <div class="col-12 col-sm-12 col-md-12 col-lg-6 d-flex justify-content-center">
                                                <div class="form-group mailsendbtn mb-0 w-100">	
                                                    <button class="btn btn-lg" id="submit-form">Send Message</button>
                                                </div>
                                            </div>
                                        </div>
</div>
                                    <div class="response-msg"></div>
                                </div>
                                    <label for=""></label>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            
            <!-- End Product Quickshop Modal -->

            <!-- Product Addtocart Modal-->
            <div class="addtocart-modal modal fade" id="addtocart_modal" tabindex="-1" aria-hidden="true">           
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <form method="post" action="#" id="product-form-addtocart" class="product-form align-items-center">
                                <h3 class="title mb-3 text-success text-center">Added to cart Successfully!</h3>
                                <div class="row d-flex-center text-center">
                                    <div class="col-md-6">
                                        <!-- Product Image -->
                                        <a class="product-image" href="product-layout1.html"><img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools3.jpg" src="<?php echo $path; ?>assets/images/products/tools3.jpg" alt="Product" title="Product" width="625" height="781" /></a>
                                        <!-- End Product Image -->
                                    </div>
                                    <div class="col-md-6 mt-3 mt-md-0">
                                        <!-- Product Info -->
                                        <div class="product-details">
                                            <div class="variant-cart mb-1">Tools-parts</div>
                                            <a class="product-title" href="product-layout1.html">Planes Hand tool</a>
                                            <p class="product-clr my-2 text-muted">Black / XL</p>
                                        </div>
                                        <div class="addcart-total rounded-5">
                                            <p class="product-items mb-2">There are <strong>1</strong> items in your cart</p>
                                            <p class="d-flex-justify-center">Total: <span class="price">$198.00</span></p>
                                        </div>
                                        <!-- End Product Info -->
                                        <!-- Product Action -->
                                        <div class="product-form-submit d-flex-justify-center">
                                            <a href="#" class="btn btn-outline-primary product-continue w-100">Continue Shopping</a>
                                            <a href="cart-style1.html" class="btn btn-secondary product-viewcart w-100 my-2 my-md-3">View Cart</a>
                                            <a href="checkout-style1.html" class="btn btn-primary product-checkout w-100">Proceed to checkout</a>
                                        </div>
                                        <!-- End Product Action -->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Product Addtocart Modal -->

            <!-- Product Quickview Modal-->
            <div class="quickview-modal modal fade" id="quickview_modal" tabindex="-1" aria-hidden="true">           
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <div class="row">
                                <div class="col-12 col-sm-6 col-md-6 col-lg-6 mb-3 mb-md-0">
                                    <!-- Model Thumbnail -->
                                    <div id="quickView" class="carousel slide">
                                        <!-- Image Slide carousel items -->
                                        <div class="carousel-inner">
                                            <div class="item carousel-item active" data-bs-slide-number="0">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools1.jpg" src="<?php echo $path; ?>assets/images/products/tools1.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                            <div class="item carousel-item" data-bs-slide-number="1">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools2.jpg" src="<?php echo $path; ?>assets/images/products/tools2.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                            <div class="item carousel-item" data-bs-slide-number="2">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools3.jpg" src="<?php echo $path; ?>assets/images/products/tools3.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                            <div class="item carousel-item" data-bs-slide-number="3">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools4.jpg" src="<?php echo $path; ?>assets/images/products/tools4.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                            <div class="item carousel-item" data-bs-slide-number="4">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools5.jpg" src="<?php echo $path; ?>assets/images/products/tools5.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                            <div class="item carousel-item" data-bs-slide-number="5">
                                                <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools6.jpg" src="<?php echo $path; ?>assets/images/products/tools6.jpg" alt="product" title="Product" width="625" height="781" />
                                            </div>
                                        </div>
                                        <!-- End Image Slide carousel items -->
                                        <!-- Thumbnail image -->
                                        <div class="model-thumbnail-img">
                                            <!-- Thumbnail slide -->
                                            <div class="carousel-indicators list-inline">
                                                <div class="list-inline-item active" id="carousel-selector-0" data-bs-slide-to="0" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools1.jpg" src="<?php echo $path; ?>assets/images/products/tools1.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                                <div class="list-inline-item" id="carousel-selector-1" data-bs-slide-to="1" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools2.jpg" src="<?php echo $path; ?>assets/images/products/tools2.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                                <div class="list-inline-item" id="carousel-selector-2" data-bs-slide-to="2" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools3.jpg" src="<?php echo $path; ?>assets/images/products/tools3.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                                <div class="list-inline-item" id="carousel-selector-3" data-bs-slide-to="3" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools4.jpg" src="<?php echo $path; ?>assets/images/products/tools4.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                                <div class="list-inline-item" id="carousel-selector-4" data-bs-slide-to="4" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools5.jpg" src="<?php echo $path; ?>assets/images/products/tools5.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                                <div class="list-inline-item" id="carousel-selector-5" data-bs-slide-to="5" data-bs-target="#quickView">
                                                    <img class="blur-up lazyload" data-src="<?php echo $path; ?>assets/images/products/tools6.jpg" src="<?php echo $path; ?>assets/images/products/tools6.jpg" alt="product" title="Product" width="625" height="781" />
                                                </div>
                                            </div>
                                            <!-- End Thumbnail slide -->
                                            <!-- Carousel arrow button -->
                                            <a class="carousel-control-prev carousel-arrow rounded-1" href="#quickView" data-bs-target="#quickView" data-bs-slide="prev"><i class="icon anm anm-angle-left-r"></i></a>
                                            <a class="carousel-control-next carousel-arrow rounded-1" href="#quickView" data-bs-target="#quickView" data-bs-slide="next"><i class="icon anm anm-angle-right-r"></i></a>
                                            <!-- End Carousel arrow button -->
                                        </div>
                                        <!-- End Thumbnail image -->
                                    </div>
                                    <!-- End Model Thumbnail -->
                                    <div class="text-center mt-3"><a href=" " class="text-link">View More Details</a></div>
                                </div>
                                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                                    <div class="product-subtitle">Tools-parts</div>
                                    <div class="product-arrow d-flex justify-content-between">
                                        <h2 class="product-title">Product Quick View Popup</h2>
                                        <div class="arrows d-flex">
                                            <a class="pro-next" href="product-layout2.html" title="Previous"><i class="icon anm anm-angle-left-l"></i></a>
                                            <a class="pro-prev" href="product-layout3.html" title="Next"><i class="icon anm anm-angle-right-l"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-review d-flex mt-0 mb-2">
                                        <div class="rating"><i class="icon anm anm-star"></i><i class="icon anm anm-star"></i><i class="icon anm anm-star"></i><i class="icon anm anm-star"></i><i class="icon anm anm-star-o"></i></div>
                                        <div class="reviews ms-2"><a href="#">6 Reviews</a></div>
                                    </div>
                                    <div class="product-info">
                                        <p class="product-vendor">Vendor:<span class="text"><a href="#">Tools-parts</a></span></p>  
                                        <p class="product-type">Product Type:<span class="text">Plasterer</span></p> 
                                        <p class="product-sku">SKU:<span class="text">RF104</span></p>
                                    </div>
                                    <div class="pro-stockLbl my-2">
                                        <span class="d-flex-center stockLbl instock d-none"><i class="icon anm anm-check-cil text-primary"></i><span> In stock</span></span>
                                        <span class="d-flex-center stockLbl preorder d-none"><i class="icon anm anm-clock-r text-primary"></i><span> Pre-order Now</span></span>
                                        <span class="d-flex-center stockLbl outstock d-none"><i class="icon anm anm-times-cil text-primary"></i> <span>Sold out</span></span>
                                        <span class="d-flex-center stockLbl lowstock" data-qty="15"><i class="icon anm anm-exclamation-cir text-primary"></i><span> Order now, Only <span class="items text-primary">10</span> left!</span></span>
                                    </div>
                                    <div class="product-price d-flex-center my-3">
                                        <span class="price old-price">$135.00</span><span class="price">$99.00</span>

                                    </div>
                                    <div class="sort-description">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</div>
                                    <form method="post" action="#" id="product_form--option" class="product-form">
                                        <div class="product-options d-flex-wrap">
                                            <div class="product-item swatches-image w-100 mb-3 swatch-0 option1" data-option-index="0">
                                                <label class="label d-flex align-items-center">Color:<span class="slVariant ms-1 fw-bold">Blue</span></label>
                                                <ul class="variants-clr swatches d-flex-center pt-1 clearfix">
                                                    <li class="swatch large radius available active"><img src="<?php echo $path; ?>assets/images/products/swatches/blue-red.jpg" alt="image" width="70" height="70" data-bs-toggle="tooltip" data-bs-placement="top" title="Blue" /></li>
                                                    <li class="swatch large radius available"><img src="<?php echo $path; ?>assets/images/products/swatches/blue-red.jpg" alt="image" width="70" height="70" data-bs-toggle="tooltip" data-bs-placement="top" title="Black" /></li>
                                                    <li class="swatch large radius available"><img src="<?php echo $path; ?>assets/images/products/swatches/blue-red.jpg" alt="image" width="70" height="70" data-bs-toggle="tooltip" data-bs-placement="top" title="Pink" /></li>
                                                    <li class="swatch large radius available green"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="Green"></span></li>
                                                    <li class="swatch large radius soldout yellow"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="Yellow"></span></li>
                                                </ul>
                                            </div>
                                            <div class="product-item swatches-size w-100 mb-3 swatch-1 option2" data-option-index="1">
                                                <label class="label d-flex align-items-center">Size:<span class="slVariant ms-1 fw-bold">S</span></label>
                                                <ul class="variants-size size-swatches d-flex-center pt-1 clearfix">
                                                    <li class="swatch large radius soldout"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="XS">XS</span></li>
                                                    <li class="swatch large radius available active"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="S">S</span></li>
                                                    <li class="swatch large radius available"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="M">M</span></li>
                                                    <li class="swatch large radius available"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="L">L</span></li>
                                                    <li class="swatch large radius available"><span class="swatchLbl" data-bs-toggle="tooltip" data-bs-placement="top" title="XL">XL</span></li>
                                                </ul>
                                            </div>
                                            <div class="product-action d-flex-wrap w-100 pt-1 mb-3 clearfix">
                                                <div class="quantity">
                                                    <div class="qtyField rounded">
                                                        <a class="qtyBtn minus" href="#;"><i class="icon anm anm-minus-r" aria-hidden="true"></i></a>
                                                        <input type="text" name="quantity" value="1" class="product-form__input qty">
                                                        <a class="qtyBtn plus" href="#;"><i class="icon anm anm-plus-l" aria-hidden="true"></i></a>
                                                    </div>
                                                </div>                                
                                                <div class="addtocart ms-3 fl-1">
                                                    <button type="submit" name="add" class="btn btn-primary product-cart-submit w-100"><i class="icon anm anm-cart-l me-2"></i><span>Add to cart</span></button>
                                                    <button type="submit" name="sold" class="btn btn-secondary product-sold-out w-100 d-none" disabled="disabled"><span>Sold out</span></button>
                                                    <button type="submit" name="buy" class="btn btn-secondary proceed-to-checkout w-100 d-none"><span>Buy it now</span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="wishlist-btn d-flex-center">
                                        <a class="add-wishlist d-flex-center me-3" href="wishlist-style1.html" title="Add to Wishlist"><i class="icon anm anm-heart-l me-1"></i> <span>Add to Wishlist</span></a>
                                        <a class="add-compare d-flex-center" href="compare-style1.html" title="Add to Compare"><i class="icon anm anm-random-r me-2"></i> <span>Add to Compare</span></a>
                                    </div>
                                    <!-- Social Sharing -->
                                    <div class="social-sharing share-icon d-flex-center mx-0 mt-3">
                                        <span class="sharing-lbl">Share :</span>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-facebook" data-bs-toggle="tooltip" data-bs-placement="top" title="Share on Facebook"><i class="icon anm anm-facebook-f"></i><span class="share-title d-none">Facebook</span></a>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-twitter" data-bs-toggle="tooltip" data-bs-placement="top" title="Tweet on Twitter"><i class="icon anm anm-twitter"></i><span class="share-title d-none">Tweet</span></a>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-pinterest" data-bs-toggle="tooltip" data-bs-placement="top" title="Pin on Pinterest"><i class="icon anm anm-pinterest-p"></i> <span class="share-title d-none">Pin it</span></a>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-linkedin" data-bs-toggle="tooltip" data-bs-placement="top" title="Share on Instagram"><i class="icon anm anm-linkedin-in"></i><span class="share-title d-none">Instagram</span></a>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-whatsapp" data-bs-toggle="tooltip" data-bs-placement="top" title="Share on WhatsApp"><i class="icon anm anm-envelope-l"></i><span class="share-title d-none">WhatsApp</span></a>
                                        <a href="#" class="d-flex-center btn btn-link btn--share share-email" data-bs-toggle="tooltip" data-bs-placement="top" title="Share by Email"><i class="icon anm anm-whatsapp"></i><span class="share-title d-none">Email</span></a>
                                    </div>
                                    <!-- End Social Sharing -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Product Quickview Modal-->

            <!--Newsletter Modal
            <div class="newsletter-modal style4 modal fade" id="newsletter_modal" tabindex="-1" aria-hidden="true">           
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content border-0">
                        <div class="modal-body p-0">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <div class="newsletter-wrap d-flex flex-row align-items-center">
                                <div class="newsltr-img col-12 col-md-5 d-none d-sm-none d-md-block">
                                    <img class="rounded-end-0 blur-up lazyload" data-src="<?php echo $path; ?>assets/images/newsletter/newsletter-s7.jpg" src="<?php echo $path; ?>assets/images/newsletter/newsletter-s7.jpg" alt="image" width="350" height="466" />
                                </div>
                                <div class="newsltr-text col-12 col-md-7 text-center text-md-start">
                                    <div class="wraptext mw-100 text-center">
                                        <h2 class="title mb-3">Sign Up For Newsletters</h2>
                                        <p class="text mb-3">Subscribe to the mailing list to receive updates on new arrivals, special offers</p>
                                        <form action="#" method="post" class="mcNewsletter mb-3">                               
                                            <div class="input-group">
                                                <input type="email" class="form-control input-group-field newsletter-input" name="email" value="" placeholder="Enter your email address..." required />
                                                <button type="submit" class="input-group-btn btn btn-secondary newsletter-submit" name="commit">Subscribe</button>
                                            </div>
                                        </form>
                                        <ul class="list-inline social-icons d-inline-flex justify-content-center mb-3 w-100">
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Facebook"><i class="icon anm anm-facebook-f"></i></a></li>
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Twitter"><i class="icon anm anm-twitter"></i></a></li>
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Pinterest"><i class="icon anm anm-pinterest-p"></i></a></li>
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Linkedin"><i class="icon anm anm-linkedin-in"></i></a></li>
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Instagram"><i class="icon anm anm-instagram"></i></a></li>
                                            <li class="list-inline-item"><a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Youtube"><i class="icon anm anm-youtube"></i></a></li>
                                        </ul>
                                        <div class="customCheckbox checkboxlink clearfix justify-content-center">
                                            <input id="dontshow" name="newsPopup" type="checkbox" />
                                            <label for="dontshow" class="mb-0">Don't show this popup again</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <!--End Newsletter Modal-->


            <!-- Including Jquery/Javascript -->
            <!-- Plugins JS -->
            <script src="<?php echo $path; ?>assets/js/plugins.js"></script>
            <!-- Main JS -->
            <script src="<?php echo $path; ?>assets/js/main.js"></script>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
    integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
    integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

            <!--Newsletter Modal Cookies-->
            <script>
                $(window).ready(function () {
                    setTimeout(function () {
                        $('#newsletter_modal').modal("show");
                    }, 7000);
                });

                function copyToClipboard() {
                // Get the text you want to copy (replace with your actual URL or content)
                var textToCopy = window.location.href;

                // Create a temporary input element
                var tempInput = document.createElement("input");
                tempInput.setAttribute("value", textToCopy);
                document.body.appendChild(tempInput);

                // Select the text in the input element
                tempInput.select();
                tempInput.setSelectionRange(0, 99999); // For mobile devices

                // Execute the "copy" command
                document.execCommand("copy");

                // Remove the temporary input element
                document.body.removeChild(tempInput);

                // Optionally, provide feedback to the user
                toastr.info("Link copied ");
            }

            var modal = document.getElementById('quickview_modal');
            var overlay = document.getElementsByClassName('modal-backdrop');

            
            
            var coursesString;

            $("#enquiry-form").click(function () {
    var courses = $('input[name="course"]:checked');

                    // Array to store selected course values
                    var selectedCourses = [];
                    // Reset the table without adding the courses
                    $("#product-table tbody").find("input[type='checkbox']").prop('checked', false);

                    // Iterate through each selected course, append it to the list, and add to the array
                    courses.each(function () {
                        var course = $(this).val();
                        $("#selected-courses-list tbody").append('<tr><td>' + course + '</td></tr>');
                        selectedCourses.push(course);
                    });

                    // Convert the array to a comma-separated string
                    coursesString = selectedCourses.join(', ');
                    if (courses.length === 0) {
                    toastr.error("Please Select at Least One Event Before Purchase");
                }
                else{
                    var modal = $('#quickview_form');
                    modal.modal('show');
                }
})

            
            $(document).ready(function () {
            $("#submit-form").click(function () {
                     
            var username = document.getElementById('ContactFormName').value;
            var email = document.getElementById('ContactFormEmail').value;
            var phone = document.getElementById('ContactFormPhone').value;
            var address = document.getElementById('ContactFormAddress').value;

        if (username === '') {
            toastr.error('Error!', 'username is required!');
        } else if (email === '') {
            toastr.error('Error!', 'email is required!');
        } else if (phone === '') {
            toastr.error('Error!', 'phone is required!');
        } else if (address === '') {
            toastr.error('Error!', 'address is required!');
        }else {
    
                    var fd = new FormData();
                    fd.append("courses", coursesString);
                    fd.append("username", username);  
                    fd.append("email", email);  
                    fd.append("phone", phone);
                    fd.append("address", address);

                    var modal = $('#quickview_form');
                    modal.modal('hide');

                    $.ajax({
                        url: 'ajax',
                        type: 'post',
                        processData: false,
                        contentType: false,
                        data: fd,

                        success: function (response) {
                            var result = JSON.parse(response);

                            if (result.status == 'Success') {
                                toastr.success("Event Successfully Added ", "Success")
                            } else {
                                toastr.error("Unable to Add", "Error")
                            }
                        }
                    })
                }
            });
            });
            </script>
            <!--End Newsletter Modal Cookies-->

        </div>
        <!--End Page Wrapper-->
    </body>

<!-- Mirrored from www.annimexweb.com/items/hema/index5-tools-parts.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 04 Oct 2023 07:16:17 GMT -->
</html>